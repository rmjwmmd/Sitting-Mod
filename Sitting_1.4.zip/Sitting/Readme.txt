The Sitting mod, created by rmjwmmd

This mod adds a move called Ass Worship, allowing you to act while in the Face Sit stance.

This mod also gives new moves and loss scenes to these monster girls:
Alraune
Minotaur
Kunoichi Trainee
Matango
Blue Slime
Bubble Slime
Ghost

I have plans for characters like Aiko and Mika, but they're taking longer to implement.

Let me know on the MGD discord or through DM's if you have feedback or questions!